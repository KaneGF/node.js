# echo "# node.js" 
## README.md
>push
- git init
- git add README.md
- git commit -m "first commit"
- git remote add origin git@github.com:KaneGF/node.js.git
- git push -u origin master

>pull
- git clone git@github.com:KaneGF/node.js.git